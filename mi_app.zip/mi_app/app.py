from flask import Flask, render_template, request, redirect, url_for, session, send_file, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
import csv
import io
from flask_socketio import SocketIO, join_room, emit

app = Flask(__name__)
app.secret_key = 'mi_secreto'

# Configurar la base de datos
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///usuarios.db'  # Ruta de la base de datos
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Desactivar advertencias
db = SQLAlchemy(app)

# Definir el modelo de Usuario
class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    lastname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    personalization = db.Column(db.Boolean, default=False)  # Personalización activada o no

    def __repr__(self):
        return f"Usuario('{self.name}', '{self.email}')"

# Definir el modelo de Evento
class Evento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    date = db.Column(db.String(100), nullable=False)  # Fecha del evento
    creator_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)  # Relación con el creador

    creator = db.relationship('Usuario', back_populates='events')  # Relación inversa con Usuario

    def __repr__(self):
        return f"Evento('{self.title}', '{self.date}')"

# Relación inversa en Usuario
Usuario.events = db.relationship('Evento', back_populates='creator')

# Modelo de Participación entre Usuario y Evento
class Participacion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    evento_id = db.Column(db.Integer, db.ForeignKey('evento.id'), nullable=False)

    # Relaciones con las tablas de Usuario y Evento
    usuario = db.relationship('Usuario', backref='participaciones')
    evento = db.relationship('Evento', backref='participaciones')


# Verificar que las tablas se creen correctamente (cuando inicies la app por primera vez)
with app.app_context():
    db.create_all()

@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('menu'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Usuario.query.filter_by(email=email).first()  # Buscar el usuario por email
        if user and user.password == password:  # Verificar la contraseña
            session['user'] = {'id': user.id, 'name': user.name, 'email': user.email, 'personalization': user.personalization}
            return redirect(url_for('menu'))
        else:
            flash("Credenciales inválidas")  # Agregar un mensaje flash si las credenciales son incorrectas
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        lastname = request.form['lastname']
        email = request.form['email']
        password = request.form['password']
        # Verificar si el usuario ya existe
        user = Usuario.query.filter_by(email=email).first()
        if user:
            flash("El usuario ya existe")  # Mensaje flash si el usuario ya existe
            return redirect(url_for('register'))
        
        nuevo_usuario = Usuario(name=name, lastname=lastname, email=email, password=password)
        db.session.add(nuevo_usuario)
        db.session.commit()  # Guardar el nuevo usuario en la base de datos
        flash('Registro exitoso. ¡Por favor, inicia sesión!')  # Mensaje flash para el registro exitoso
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/menu')
def menu():
    if 'user' not in session:
        return redirect(url_for('login'))

    # Obtener los eventos a los que el usuario está unido
    eventos_participados = Evento.query.join(Participacion).filter(Participacion.usuario_id == session['user']['id']).all()

    return render_template('menu.html', eventos=eventos_participados)


@app.route('/create_event', methods=['GET', 'POST'])
def create_event():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        date = request.form['date']
        # Crear un nuevo evento y guardarlo en la base de datos
        new_event = Evento(title=title, date=date, creator_id=session['user']['id'])
        db.session.add(new_event)
        db.session.commit()  # Guardar el evento en la base de datos
        flash('Evento creado exitosamente.')  # Mensaje flash para el evento creado
        return redirect(url_for('events_list'))

    return render_template('create_event.html')

@app.route('/events')
def events_list():
    if 'user' not in session:
        return redirect(url_for('login'))

    # Obtener los eventos del usuario logueado
    events = Evento.query.filter_by(creator_id=session['user']['id']).all()  # Solo los eventos creados por el usuario
    return render_template('events.html', events=events)

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect(url_for('login'))

    # Obtener el usuario desde la base de datos
    user = Usuario.query.get(session['user']['id'])
    
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        personalization = request.form.get('personalization') == 'on'  # Personalización activada si el checkbox está marcado
        user.name = name
        user.email = email
        user.personalization = personalization
        db.session.commit()  # Guardar cambios en la base de datos
        session['user'] = {'id': user.id, 'name': user.name, 'email': user.email, 'personalization': user.personalization}
        flash('Perfil actualizado exitosamente.')  # Mensaje flash para la actualización del perfil
        return redirect(url_for('profile'))

    return render_template('profile.html', user=user)

@app.route('/privacy')
def privacy_policy():
    return render_template('privacy_policy.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Has cerrado sesión exitosamente.')  # Mensaje flash para el cierre de sesión
    return redirect(url_for('login'))

@app.route('/delete_account')
def delete_account():
    if 'user' in session:
        user = Usuario.query.get(session['user']['id'])
        db.session.delete(user)  # Eliminar el usuario de la base de datos
        db.session.commit()
        session.clear()
        flash('Cuenta eliminada exitosamente.')  # Mensaje flash para la eliminación de la cuenta
    return redirect(url_for('login'))

@app.route('/download_json')
def download_json():
    if 'user' not in session:
        return redirect(url_for('login'))
    return jsonify(session['user'])

@app.route('/download_csv')
def download_csv():
    if 'user' not in session:
        return redirect(url_for('login'))
    user = session['user']
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Nombre', 'Apellido', 'Email'])

    # Aquí se asegura de que `lastname` está en la sesión
    writer.writerow([user['name'], user.get('lastname', 'No disponible'), user['email']])
    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv', as_attachment=True, download_name='datos_usuario.csv')

@app.route('/toggle_personalization', methods=['POST'])
def toggle_personalization():
    if 'user' in session:
        user = Usuario.query.get(session['user']['id'])
        user.personalization = not user.personalization
        db.session.commit()  # Guardar cambios en la base de datos
        session['user']['personalization'] = user.personalization
    return redirect(url_for('profile'))

#Eventos en grupo
@app.route('/join_event/<int:evento_id>')
def join_event(evento_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    # Verificar si el usuario ya está en el evento
    if Participacion.query.filter_by(usuario_id=session['user']['id'], evento_id=evento_id).first():
        flash('Ya te has unido a este evento.')
        return redirect(url_for('events_list'))
    
    # Unir al usuario al evento
    participacion = Participacion(usuario_id=session['user']['id'], evento_id=evento_id)
    db.session.add(participacion)
    db.session.commit()  # Guardar la participación en la base de datos
    flash('Te has unido al evento exitosamente.')
    
    return redirect(url_for('event_detail', evento_id=evento_id))

@app.route('/event_detail/<int:evento_id>')
def event_detail(evento_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    evento = Evento.query.get_or_404(evento_id)
    
    # Obtener los usuarios participantes del evento
    participantes = Usuario.query.join(Participacion).filter(Participacion.evento_id == evento.id).all()
    
    # Aquí deberías consultar las encuestas asociadas al evento
    encuestas = []  # Asumiendo que tienes el modelo Encuesta

    return render_template('event_detail.html', evento=evento, participantes=participantes, encuestas=encuestas)

# Configuración de SocketIO
socketio = SocketIO(app)

# Evento de conexión del socket
@socketio.on('connect')
def handle_connect():
    print('Usuario conectado')

# Evento para unirse a un chat de evento
@socketio.on('join_event')
def handle_join_event(evento_id):
    room = f'evento_{evento_id}'  # Nombre de la "habitación" o grupo
    join_room(room)
    print(f'Usuario unido a evento {evento_id}')
    emit('message', {'msg': f'Usuario se unió al evento {evento_id}'}, room=room)

# Evento para enviar mensajes
@socketio.on('send_message')
def handle_send_message(data):
    evento_id = data['evento_id']
    room = f'evento_{evento_id}'
    emit('message', {'msg': data['message']}, room=room)

# Evento de desconexión
@socketio.on('disconnect')
def handle_disconnect():
    print('Usuario desconectado')

if __name__ == '__main__':
    socketio.run(app, debug=True)
    
