import sqlite3

# Conectar a la base de datos
conn = sqlite3.connect('usuarios.db')
cursor = conn.cursor()

# Crear la tabla de Usuario
cursor.execute('''
    CREATE TABLE IF NOT EXISTS usuario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        lastname TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        personalization BOOLEAN DEFAULT 0
    )
''')

# Crear la tabla de Evento
cursor.execute('''
    CREATE TABLE IF NOT EXISTS evento (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        date TEXT NOT NULL,
        creator_id INTEGER,
        FOREIGN KEY (creator_id) REFERENCES usuario(id) ON DELETE CASCADE
    )
''')

# Confirmar los cambios y cerrar la conexión
conn.commit()
conn.close()
